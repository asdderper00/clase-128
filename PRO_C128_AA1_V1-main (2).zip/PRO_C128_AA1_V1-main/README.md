# PRO_C128_AA1_V1
SCRAPING WEB - 2  
BeautifulSoup. Selenium.  
  
Plan de la clase.  
Plantilla del código del alumno.  
